package Operations;

public class Constants {
	
	public static final String tablePath = ".\\src\\tables\\";
	public static final String dbFilePath = ".\\src\\db\\";
	
}
