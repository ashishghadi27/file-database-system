package tables;
public class Students { 

	private Integer RollNo; 
	private Float CGPA; 
	private Integer Id; 
	private String Name; 

	public Integer getRollNo() {
 		return RollNo;
 	}

	public void setRollNo(Integer RollNo) {
 		 this.RollNo = RollNo;
 	}

	public Float getCGPA() {
 		return CGPA;
 	}

	public void setCGPA(Float CGPA) {
 		 this.CGPA = CGPA;
 	}

	public Integer getId() {
 		return Id;
 	}

	public void setId(Integer Id) {
 		 this.Id = Id;
 	}

	public String getName() {
 		return Name;
 	}

	public void setName(String Name) {
 		 this.Name = Name;
 	}

}